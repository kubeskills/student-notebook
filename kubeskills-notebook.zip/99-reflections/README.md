# Reflections Folder

Use this folder to track your weekly progress. Create a new file for each week (e.g., week1.md, week2.md, etc.).

Each reflection should include:
- ✅ What you learned
- ❓ Questions you still have
- 💡 Useful commands or tools
