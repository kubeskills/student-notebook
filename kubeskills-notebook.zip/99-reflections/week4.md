# Week 4 Reflection – Services and Ingress

In this week, I explored Kubernetes networking through Services and Ingress.  
Here are my reflections on what I learned, what challenged me, and how you might apply it.

---

## ✅ What I Learned

- 

---

## ❓ What Was Challenging

- 

---

## 🧪 Commands I Practiced

```bash

```

---

## 🌐 Concepts I Better Understand Now

- 

---

## 💡 How I Might Use This in the Real World

- 

---

## 📝 Questions I Still Have

- 

---

## 📎 Related YAMLs

- `web-pod.yaml`
- `web-service.yaml`
- `web-ingress.yaml`

---

## 🚀 What's Next

Try deploying a second app and routing it through the same Ingress controller using a different path like `/v2`.

Or submit your own Week 5 lab idea as a PR!
