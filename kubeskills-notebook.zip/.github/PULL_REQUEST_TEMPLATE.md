# 🧠 GROW Notebook Contribution or Question

Thanks for contributing to your student notebook or reaching out with a question!

Please complete the relevant section(s) below.

---

## 📝 Suggested PR Title

> Format your PR title like one of the following:
> - `lab: add nginx pod with securityContext`
> - `reflection: week2 submission`
> - `question: FluxCD error in apply`

---

## ✍️ What is this PR for?

- [ ] I’m updating or adding new lab work
- [ ] I’m submitting a reflection or weekly journal
- [ ] I have a question for a KubeSkills instructor

---

## 📝 Description

<!-- Describe your change or question in detail. If it's a question, explain what you tried and what you're stuck on. -->

---

## 📎 Related Files

<!-- List any YAML, Markdown, or scripts you’re referencing in your notebook -->

---

## 🙋‍♂️ What do you need help with?

<!-- Optional if submitting a question -->
